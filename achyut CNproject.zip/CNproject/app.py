from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Secret key for session management

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db = SQLAlchemy(app)

# Configuration for image uploads
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Sample user data
users = {'admin': 'password123'}  # Replace with a database in production

### Database Models ###

class LoginLogoutLog(db.Model):
    __tablename__ = 'login_logout_log'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False)
    action = db.Column(db.String(50), nullable=False)  # 'login' or 'logout'
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class ImageMetadata(db.Model):
    __tablename__ = 'image_metadata'
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(300), nullable=False)
    caption = db.Column(db.String(500))
    likes = db.Column(db.Integer, default=0)
    comments = db.relationship('Comment', backref='image', lazy=True)

class Comment(db.Model):
    __tablename__ = 'comments'
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(500), nullable=False)
    image_id = db.Column(db.Integer, db.ForeignKey('image_metadata.id'), nullable=False)


# Create tables
with app.app_context():
    db.create_all()

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Check credentials
        if username in users and users[username] == password:
            session['username'] = username
            # Log the login action
            log_entry = LoginLogoutLog(username=username, action='login')
            db.session.add(log_entry)
            db.session.commit()
            return redirect(url_for('upload_page'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
def logout():
    username = session.get('username')
    # Log the logout action
    if username:
        log_entry = LoginLogoutLog(username=username, action='logout')
        db.session.add(log_entry)
        db.session.commit()
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/upload', methods=['GET', 'POST'])
def upload_page():
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        if 'image' not in request.files:
            return "No file part in the request"

        file = request.files['image']
        if file.filename == '':
            return "No file selected"

        # Secure the file name and save the image
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        # Get metadata from form
        caption = request.form.get('caption')
        likes = request.form.get('likes', type=int, default=0)
        comments = request.form.getlist('comments')

        # Save image metadata to the database
        image = ImageMetadata(filename=filename, caption=caption, likes=likes)
        db.session.add(image)
        db.session.commit()

        # Save comments to the database
        for comment_text in comments:
            if comment_text.strip():
                comment = Comment(content=comment_text, image_id=image.id)
                db.session.add(comment)
        db.session.commit()

        return redirect(url_for('view_images'))
    return render_template('upload.html')

@app.route('/images')
def view_images():
    if 'username' not in session:
        return redirect(url_for('login'))
    # Retrieve images and their comments
    images = ImageMetadata.query.all()
    return render_template('view_images.html', images=images)

if __name__ == '__main__':
    app.run(debug=True)